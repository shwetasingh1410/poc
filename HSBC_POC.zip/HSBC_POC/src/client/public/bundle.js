/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/* unknown exports provided */
/* all exports used */
/*!**********************************!*\
  !*** ./src/client/app/index.jsx ***!
  \**********************************/
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nvar Dropdown = React.createClass({\n\tdisplayName: \"Dropdown\",\n\n\tgetInitialState: function getInitialState() {\n\t\treturn {\n\t\t\tlistVisible: false\n\t\t};\n\t},\n\n\tselect: function select(item) {\n\t\tthis.props.selected = item;\n\t},\n\n\tshow: function show() {\n\t\tthis.setState({ listVisible: true });\n\t\tdocument.addEventListener(\"click\", this.hide);\n\t},\n\n\thide: function hide() {\n\t\tthis.setState({ listVisible: false });\n\t\tdocument.removeEventListener(\"click\", this.hide);\n\t},\n\n\trender: function render() {\n\t\treturn React.createElement(\n\t\t\t\"div\",\n\t\t\t{ className: \"dropdown-container\" + (this.state.listVisible ? \" show\" : \"\") },\n\t\t\tReact.createElement(\n\t\t\t\t\"div\",\n\t\t\t\t{ className: \"dropdown-display\" + (this.state.listVisible ? \" clicked\" : \"\"), onClick: this.show },\n\t\t\t\tReact.createElement(\n\t\t\t\t\t\"span\",\n\t\t\t\t\tnull,\n\t\t\t\t\tthis.props.selected.name\n\t\t\t\t),\n\t\t\t\tReact.createElement(\"i\", { className: \"fa fa-angle-down\" })\n\t\t\t),\n\t\t\tReact.createElement(\n\t\t\t\t\"div\",\n\t\t\t\t{ className: \"dropdown-list\" },\n\t\t\t\tReact.createElement(\n\t\t\t\t\t\"div\",\n\t\t\t\t\tnull,\n\t\t\t\t\tthis.renderListItems()\n\t\t\t\t)\n\t\t\t)\n\t\t);\n\t},\n\n\trenderListItems: function renderListItems() {\n\t\tvar items = [];\n\t\tfor (var i = 0; i < this.props.list.length; i++) {\n\t\t\tvar item = this.props.list[i];\n\t\t\titems.push(React.createElement(\n\t\t\t\t\"div\",\n\t\t\t\t{ onClick: this.select.bind(null, item) },\n\t\t\t\tReact.createElement(\n\t\t\t\t\t\"label\",\n\t\t\t\t\tnull,\n\t\t\t\t\titem.name\n\t\t\t\t),\n\t\t\t\tReact.createElement(\n\t\t\t\t\t\"span\",\n\t\t\t\t\tnull,\n\t\t\t\t\t\" \",\n\t\t\t\t\titem.details\n\t\t\t\t),\n\t\t\t\tReact.createElement(\"i\", { className: \"fa fa-check\" })\n\t\t\t));\n\t\t}\n\t\treturn items;\n\t}\n});\n\nvar accounts = [{\n\tname: \"Philippines HBA P\",\n\tdetails: \"FTT RESKIN ACC 02\",\n\tcode: \"011-331155-100\"\n}, {\n\tname: \"CANADA HBCA\",\n\tdetails: \"CA ACNT\",\n\tcode: \"011-001221-076\"\n}, {\n\tname: \"FRANCE HBA F\",\n\tdetails: \"FA ACNT\",\n\tcode: \"001-001221-088\"\n}];\n\nReact.render(React.createElement(Dropdown, { list: accounts, selected: accounts[0] }), document.getElementById(\"container\"));\nReact.render(React.createElement(Dropdown, { list: accounts, selected: accounts[0] }), document.getElementById(\"container_2\"));//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMC5qcyIsInNvdXJjZXMiOlsid2VicGFjazovLy9zcmMvY2xpZW50L2FwcC9pbmRleC5qc3g/Y2NhMyJdLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgRHJvcGRvd24gPSBSZWFjdC5jcmVhdGVDbGFzcyh7XHJcblx0XHRcdFx0Z2V0SW5pdGlhbFN0YXRlOiBmdW5jdGlvbigpIHtcclxuXHRcdFx0XHRcdHJldHVybiB7XHJcblx0XHRcdFx0XHRcdGxpc3RWaXNpYmxlOiBmYWxzZSxcclxuXHRcdFx0XHRcdH07XHJcblx0XHRcdFx0fSxcclxuXHRcdFx0XHRcclxuXHRcdFx0XHRzZWxlY3Q6IGZ1bmN0aW9uKGl0ZW0pIHtcclxuXHRcdFx0XHRcdHRoaXMucHJvcHMuc2VsZWN0ZWQgPSBpdGVtO1xyXG5cdFx0XHRcdH0sXHJcblx0XHRcdFx0XHJcblx0XHRcdFx0c2hvdzogZnVuY3Rpb24oKSB7XHJcblx0XHRcdFx0XHR0aGlzLnNldFN0YXRlKHsgbGlzdFZpc2libGU6IHRydWUgfSk7XHJcblx0XHRcdFx0XHRkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgdGhpcy5oaWRlKTtcclxuXHRcdFx0XHR9LFxyXG5cdFx0XHRcdFxyXG5cdFx0XHRcdGhpZGU6IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdFx0dGhpcy5zZXRTdGF0ZSh7IGxpc3RWaXNpYmxlOiBmYWxzZSB9KTtcclxuXHRcdFx0XHRcdGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCB0aGlzLmhpZGUpO1xyXG5cdFx0XHRcdH0sXHJcblx0XHRcdFxyXG5yZW5kZXI6IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdFx0cmV0dXJuIDxkaXYgY2xhc3NOYW1lPXtcImRyb3Bkb3duLWNvbnRhaW5lclwiICsgKHRoaXMuc3RhdGUubGlzdFZpc2libGUgPyBcIiBzaG93XCIgOiBcIlwiKX0+XHJcblx0XHRcdFx0XHRcdDxkaXYgY2xhc3NOYW1lPXtcImRyb3Bkb3duLWRpc3BsYXlcIiArICh0aGlzLnN0YXRlLmxpc3RWaXNpYmxlID8gXCIgY2xpY2tlZFwiOiBcIlwiKX0gb25DbGljaz17dGhpcy5zaG93fT5cclxuXHRcdFx0XHRcdFx0XHQ8c3Bhbj57dGhpcy5wcm9wcy5zZWxlY3RlZC5uYW1lfTwvc3Bhbj5cclxuXHRcdFx0XHRcdFx0XHQ8aSBjbGFzc05hbWU9XCJmYSBmYS1hbmdsZS1kb3duXCI+PC9pPlxyXG5cdFx0XHRcdFx0XHQ8L2Rpdj5cclxuXHRcdFx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJkcm9wZG93bi1saXN0XCI+XHJcblx0XHRcdFx0XHRcdFx0PGRpdj5cclxuXHRcdFx0XHRcdFx0XHRcdHt0aGlzLnJlbmRlckxpc3RJdGVtcygpfVxyXG5cdFx0XHRcdFx0XHRcdDwvZGl2PlxyXG5cdFx0XHRcdFx0XHQ8L2Rpdj5cclxuXHRcdFx0XHRcdDwvZGl2PjtcclxuXHRcdFx0XHR9LFxyXG5cdFx0XHRcdFxyXG5yZW5kZXJMaXN0SXRlbXM6IGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdFx0dmFyIGl0ZW1zID0gW107XHJcblx0XHRcdFx0XHRmb3IgKHZhciBpID0gMDsgaSA8IHRoaXMucHJvcHMubGlzdC5sZW5ndGg7IGkrKykge1xyXG5cdFx0XHRcdFx0XHR2YXIgaXRlbSA9IHRoaXMucHJvcHMubGlzdFtpXTtcclxuXHRcdFx0XHRcdFx0aXRlbXMucHVzaCg8ZGl2IG9uQ2xpY2s9e3RoaXMuc2VsZWN0LmJpbmQobnVsbCwgaXRlbSl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsPntpdGVtLm5hbWV9PC9sYWJlbD48c3Bhbj4ge2l0ZW0uZGV0YWlsc308L3NwYW4+XHJcblx0XHRcdFx0XHRcdFx0PGkgY2xhc3NOYW1lPVwiZmEgZmEtY2hlY2tcIj48L2k+XHJcblx0XHRcdFx0XHRcdDwvZGl2Pik7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHRyZXR1cm4gaXRlbXM7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9KTtcclxuXHRcdFx0XHJcbnZhciBhY2NvdW50cyA9IFt7XHJcblx0XHRcdFx0bmFtZTogXCJQaGlsaXBwaW5lcyBIQkEgUFwiLFxyXG4gICAgICAgICAgICAgICAgZGV0YWlsczpcIkZUVCBSRVNLSU4gQUNDIDAyXCIsXHJcbiAgICAgICAgICAgICAgICBjb2RlIDogXCIwMTEtMzMxMTU1LTEwMFwiXHJcblx0XHRcdH0sIHtcclxuXHRcdFx0XHRuYW1lOiBcIkNBTkFEQSBIQkNBXCIsXHJcbiAgICAgICAgICAgICAgICAgZGV0YWlsczpcIkNBIEFDTlRcIixcclxuICAgICAgICAgICAgICAgIGNvZGUgOiBcIjAxMS0wMDEyMjEtMDc2XCJcclxuXHRcdFx0fSwge1xyXG5cdFx0XHRcdG5hbWU6IFwiRlJBTkNFIEhCQSBGXCIsXHJcbiAgICAgICAgICAgICAgICBkZXRhaWxzOlwiRkEgQUNOVFwiLFxyXG4gICAgICAgICAgICAgICAgY29kZSA6IFwiMDAxLTAwMTIyMS0wODhcIlxyXG5cdFx0XHR9XTtcclxuXHJcblJlYWN0LnJlbmRlcig8RHJvcGRvd24gbGlzdD17YWNjb3VudHN9IHNlbGVjdGVkPXthY2NvdW50c1swXX0gLz4sIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiY29udGFpbmVyXCIpKTtcclxuUmVhY3QucmVuZGVyKDxEcm9wZG93biBsaXN0PXthY2NvdW50c30gc2VsZWN0ZWQ9e2FjY291bnRzWzBdfSAvPiwgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJjb250YWluZXJfMlwiKSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIHNyYy9jbGllbnQvYXBwL2luZGV4LmpzeCJdLCJtYXBwaW5ncyI6Ijs7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFEQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFGQTtBQUlBO0FBQUE7QUFBQTtBQUNBO0FBQUE7QUFBQTtBQUNBO0FBREE7QUFEQTtBQUxBO0FBV0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRkE7QUFJQTtBQUNBO0FBQ0E7QUE3Q0E7QUFDQTtBQStDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBS0E7QUFDQTtBQUNBO0FBSEE7QUFLQTtBQUNBO0FBQ0E7QUFIQTtBQUNBO0FBS0E7QUFDQSIsInNvdXJjZVJvb3QiOiIifQ==");

/***/ })
/******/ ]);