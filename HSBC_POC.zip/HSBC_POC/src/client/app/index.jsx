var Dropdown = React.createClass({
				getInitialState: function() {
					return {
						listVisible: false,
					};
				},
				
				select: function(item) {
					this.props.selected = item;
				},
				
				show: function() {
					this.setState({ listVisible: true });
					document.addEventListener("click", this.hide);
				},
				
				hide: function() {
					this.setState({ listVisible: false });
					document.removeEventListener("click", this.hide);
				},
			
render: function() {
					return <div className={"dropdown-container" + (this.state.listVisible ? " show" : "")}>
						<div className={"dropdown-display" + (this.state.listVisible ? " clicked": "")} onClick={this.show}>
							<span>{this.props.selected.name}</span>
							<i className="fa fa-angle-down"></i>
						</div>
						<div className="dropdown-list">
							<div>
								{this.renderListItems()}
							</div>
						</div>
					</div>;
				},
				
renderListItems: function() {
					var items = [];
					for (var i = 0; i < this.props.list.length; i++) {
						var item = this.props.list[i];
						items.push(<div onClick={this.select.bind(null, item)}>
                            <label class="labelClass">{item.name}</label><span> {item.details}</span>
                            <span> {item.code}</span>
							<i className="fa fa-check"></i>
						</div>);
					}
					return items;
				}
			});
			
var accounts = [{
				name: "Philippines HBA P",
                details:"FTT RESKIN ACC 02",
                code : "011-331155-100"
			}, {
				name: "CANADA HBCA",
                 details:"CA ACNT",
                code : "011-001221-076"
			}, {
				name: "FRANCE HBA F",
                details:"FA ACNT",
                code : "001-001221-088"
			}];

React.render(<Dropdown list={accounts} selected={accounts[0]} />, document.getElementById("container"));
React.render(<Dropdown list={accounts} selected={accounts[0]} />, document.getElementById("container_2"));