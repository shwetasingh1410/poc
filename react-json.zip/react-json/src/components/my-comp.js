import React, {Component} from 'react';

export default class Comp1 extends Component{
    render(){
        return(
            <div>
               Enter Name: <input type="text"/> 
            </div>
        );
    }
}

