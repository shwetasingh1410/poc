import React, {Component} from 'react';

export default class Comp2 extends Component{
    render(){
        return(
            <div>
                Enter Phone:<input type="text" />
            </div>
        );
    }
}



