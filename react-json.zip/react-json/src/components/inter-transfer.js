import React, {Component} from 'react';
//import Comp1 from './my-comp';
//import Comp2 from './ur-comp';
import '../App.css';
import compList from './component-list';
import DATA from './data.js';

export default class InterTransfer extends Component {

  constructor(props) {
    super(props);
    this.state = {};
  }
/*
  componentDidMount() {
    console.log("mounted");
    //const url ='http://localhost:54501/'
    
   // fetch('../data.json')
   //fetch(url,{'mode': 'no-cors'})
  
   fetch("http://localhost:57364/", {mode: 'no-cors'})
    .then(result => result.json())
    .then(json => {
      console.log(json.name);
     // this.setState({data});
    });
    
  }
  */

  componentDidMount() {
    console.log("mounted");
    const url = './data.js'
    fetch(url)
    .then(result => result.json())
    .then(data => {
      console.log(data);
      this.setState({data});
    });
  }


  render() {
    return (
      <div className="form">
      
        <h3>Enter Details </h3>
        {this.state.data ? this.state.data.root.data.loginRs.status : "Fetching data"}
        {
         
          this.props.comp.map( ele => {
           // debugger
            var E1 = compList[ele];
           return <E1/>
          
          }
          )
          
        }
        <div className="form">
          <br/>
        </div>
      </div>
    )
  }
}
