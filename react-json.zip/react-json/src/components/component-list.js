import Comp1 from './my-comp';
import Comp2 from './ur-comp';

const listOfAllComponents = {
  Comp1,
  Comp2
};

export default listOfAllComponents;
