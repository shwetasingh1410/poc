import React, { Component } from 'react';
import './App.css';
import InterTransfer from './components/inter-transfer'
import Comp1 from './components/my-comp';
import Comp2 from './components/ur-comp';
class App extends Component {
  render() {
    return (
      <div className="App">
        <div className="App-header">
          <h2>Move Money</h2>
        </div>
        <InterTransfer comp={['Comp1', 'Comp2']} />
        <br/>
        

      </div>
    );
  }
}

export default App;
